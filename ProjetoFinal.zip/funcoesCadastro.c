// Fun��es relacionadas aos dados de Cadastros

#include "dados.h"
